<html lang="NL">
<head>
    <link ref="zelfstanding.html"></link>
    <link ref="zelfstandingEN.html"></link>
    <link ref="zelfstandingtesting.css"></link>

    <script>
        function name(params) {
            
        } switchlanguage(language) 
            const elements = document.queryselectorALL('[data-lang]');
        
    </script>
<body>


</body>
</head>
</html>